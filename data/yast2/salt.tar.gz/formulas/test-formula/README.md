# Test formula for the SUSE Manager Salt formula framework

This formula is a test formula for the SUSE Manager Salt formula framework. It showcases most of the functionallity the framwork currently offers, but doesn't have any real functionality.
