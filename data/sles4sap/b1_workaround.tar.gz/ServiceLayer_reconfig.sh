#!/bin/bash
set -x

source "${INSTALL_SCRIPT_TEMP_DIR}/WizardUtils_parameter.sh"
source "${INSTALL_SCRIPT_TEMP_DIR}/ServerTools_service.sh"
source "${INSTALL_SCRIPT_TEMP_DIR}/ServiceLayer_common.sh"

#LANDSCAPE_SERVER_ADDRESS
#LANDSCAPE_SERVER_PORT
#SL_LB_MEMBERS
#SL_LB_MEMBER_ONLY
#SL_LB_PORT
#SL_THREAD_PER_SERVER
#SECURITY_CERTIFICATE_ACTION
#SECURITY_CERTIFICATE_FILE
#SECURITY_CERTIFICATE_PASSWD
#HANA_SERVER_ADDRESS
#HANA_SERVER_PORT
#HANA_SERVER_USER
#HANA_SERVER_PASSWD

#input env
#USER_INSTALL_DIR

# *********************************************************
# Input environment variables
# *********************************************************
# : "${USER_INSTALL_DIR:="/usr/sap/SAPBusinessOne"}"
# : "${SL_LB_PORT:="50000"}"

# *********************************************************
# Apache HTTP Server folder and files
# *********************************************************
HTTPD_FOLDER="$USER_INSTALL_DIR"/Common/httpd
HTTPD_BIN_FOLDER="$HTTPD_FOLDER"/bin
HTTPD_LIB_FOLDER="$HTTPD_FOLDER"/lib
HTTPD="$HTTPD_BIN_FOLDER"/httpd

SLD_LOG_FOLDER="$USER_INSTALL_DIR"/logs
SLD_COMMON_LIB_FOLDER="$USER_INSTALL_DIR"/Common/lib

# *********************************************************
# Service Layer folder and files
# *********************************************************
SL_INSTALLATION_FOLDER="$USER_INSTALL_DIR"/ServiceLayer
SL_LB_FILE="httpd-b1s-lb.conf"
SL_LB_MEMBER_COMMON_FILE="httpd-b1s-lb-member-common.conf"
SL_SERVICE_NAME="b1s"
SL_CONFIG_FILE="b1s.conf"
SL_CONFIG_FOLDER="$SL_INSTALLATION_FOLDER"/conf
SL_CONFIG_BACKUP_FOLDER="$TEMP_DIR"/BackUp/ServiceLayer
SL_LIB_FOLDER="$SL_INSTALLATION_FOLDER"/lib
SL_DOC_FOLDER="$SL_INSTALLATION_FOLDER"/doc
SL_TEMPLATE_FOLDER="$SL_INSTALLATION_FOLDER"/template

SL_SERVICE_FILE="$SL_INSTALLATION_FOLDER"/"$SL_SERVICE_NAME"
SL_TEMPLATE_FOLDER="$SL_INSTALLATION_FOLDER"/template
SL_LB_MEMBER_TEMPLATE_FILE="$SL_TEMPLATE_FOLDER"/httpd-b1s-lb-member.conf
SL_LB_MEMBER_FILE="$SL_INSTALLATION_FOLDER"/httpd-b1s-lb-member.conf
SL_CONFIG_SERVICE_FILE="$SL_TEMPLATE_FOLDER"/$SL_SERVICE_NAME
INIT_D_FOLDER="/etc/init.d"
SL_LB_MEMBERS="${SL_LB_MEMBERS// /}"
SL_SERVICETOKEN_KEY="$SL_CONFIG_FOLDER"/STKey.key

SL_BIN_FOLDER="$SL_INSTALLATION_FOLDER"/bin
SL_SERVICE="$SL_INSTALLATION_FOLDER"/"$SL_SERVICE_NAME"

SL_PEM_CERTIFICATE="$SL_CONFIG_FOLDER"/server.crt
SL_PEM_CERTIFICATE_CHAIN="$SL_CONFIG_FOLDER"/server-ca.crt
SL_PEM_CERTIFICATE_KEY="$SL_CONFIG_FOLDER"/server.key

# *********************************************************
# python script folder
# *********************************************************
SCRIPT_FOLDER="$USER_INSTALL_DIR"/Common/support/bin

# *********************************************************
# Register to sld
# *********************************************************
SL_COMPONENT_ID=
CLIENT_ID=
STORE_PASSWORD=
ENCRYPT_STORE_PASSWORD=

function backup_conf_file() {
    local filename="$1"
    local backup_conf_folder="$TEMP_DIR/BackUp/ServiceLayer/conf"
    echo "Backup the original conf file $filename..."
    cp "$filename" "$backup_conf_folder"
    return 0
}

function restore_conf_files_on_reconfig_failure() {
    echo "Restoring conf files..."
    local backup_conf_folder="$TEMP_DIR/BackUp/ServiceLayer/conf"
    mv "$backup_conf_folder/*" "$SL_CONFIG_FOLDER"
    return 0
}

function update_certificate() {
    cp --force "${CERTIFICATE_STORAGE_FILE:?}" "${SL_P12_CERTIFICATE:?}"

    app_options=()
    if is_v3_upper_openssl; then
        app_options+=("-legacy")
    fi
    
    # Convert certificate from PKCS12 to PEM format
    openssl pkcs12 -in "$SL_P12_CERTIFICATE" -clcerts -passin pass:"$SECURITY_CERTIFICATE_PASSWD" -nokeys -out "$SL_PEM_CERTIFICATE" "${app_options[@]}"
    openssl pkcs12 -in "$SL_P12_CERTIFICATE" -cacerts -passin pass:"$SECURITY_CERTIFICATE_PASSWD" -nokeys -out "$SL_PEM_CERTIFICATE_CHAIN" "${app_options[@]}"
    openssl pkcs12 -in "$SL_P12_CERTIFICATE" -nocerts -passin pass:"$SECURITY_CERTIFICATE_PASSWD" -nodes -out "$SL_PEM_CERTIFICATE_KEY" "${app_options[@]}"
    rm -f "$SL_P12_CERTIFICATE"
    
    sed -i '/SSLCertificateChainFile/d' "${SL_CONFIG_FOLDER}/${SL_LB_FILE}"
    if [[ -s "$SL_PEM_CERTIFICATE_CHAIN" ]]; then
        sed -i '/SSLCertificateKeyFile/i   SSLCertificateChainFile \"conf/server-ca.crt\"' "${SL_CONFIG_FOLDER}/${SL_LB_FILE}"
    fi
    
    chown b1service0:b1service0 "$SL_PEM_CERTIFICATE"
    chown b1service0:b1service0 "$SL_PEM_CERTIFICATE_KEY"
    chown b1service0:b1service0 "$SL_PEM_CERTIFICATE_CHAIN"
    
    return 0
}

function ReRegisterServicelayer() {
    echo "Reading service layer component id from b1s.conf..."
    servertools::service::check_access_status_of_sld || return 1
    
    echo "Unregistering Service Layer from old SLD $LANDSCAPE_SERVER_ADDRESS_OLD : $LANDSCAPE_SERVER_PORT_OLD ..."
    service_layer::landscape::unregister || true
    service_layer::landscape::remove_oauth_client || true
    service_layer::landscape::remove_controller_oauth_client || true
    
    echo "Registering Service Layer to new SLD $LANDSCAPE_SERVER_ADDRESS : $LANDSCAPE_SERVER_PORT ..."
    
    service_layer::landscape::register || exit 1
    
    key=$(openssl rand -base64 32)
    echo "${key}" > "$SL_SERVICETOKEN_KEY"
    chown "${B1_SERVICE_USER:?}:${B1_SERVICE_GROUP:?}" "$SL_SERVICETOKEN_KEY"
    chmod 400 "$SL_SERVICETOKEN_KEY"
    
    LOCAL_HOSTNAME=$(hostname | tr '[:upper:]' '[:lower:]')
    ODBC_DRIVER_PATH=$(awk -F= 'system("test -f " $1 "/libodbcHDB.so")==0 {print $1}' "/var/opt/.hdb/${LOCAL_HOSTNAME}/installations.client")
    export LD_LIBRARY_PATH="/usr/lib:/usr/lib64:.:${SL_LIB_FOLDER}:${SLD_COMMON_LIB_FOLDER}:${ODBC_DRIVER_PATH}:${LD_LIBRARY_PATH}"
    
    
    #Begin to bind servicelayer
    service_layer::landscape::bind || exit 1
    #End to bind servicelayer
    
    #Begin service layer controller
    echo "Register servicelayer controller..."
    service_layer::landscape::register_controller || exit 1
    #End service layer controller
    
    #Begin to bind oidc
    #get clientID and storePassword from SLDInstallerTool
    echo "creating oauth client..."
    set +x
    result=$(service_layer::landscape::create_oauth_client)
    service_layer::landscape::create_controller_oauth_client || exit 1
    
    #On success, the above command returns: true&b1-B1ServiceLayers-1409-main-sbo&Zyl/Sef6J7&yRW1vj55EP&/opt/sap/SAPBusinessOne/ServiceLayer/conf/SLD-config.p12
    IFS='&' read -r _ CLIENT_ID _ STORE_PASSWORD _ <<< "${result}"
    
    ENCRYPT_STORE_PASSWORD=$("$SL_ENCRYPT" /K "${key}" "$STORE_PASSWORD")
    #End to bind oidc
    set -x

    mv "$SL_CONFIG_FOLDER/$SL_CONFIG_FILE" "$SL_CONFIG_FOLDER/$SL_CONFIG_FILE.$$"
    python3 "${INSTALL_TEMP_DIR}/Common/support/bin/ServiceLayer_installhelper.py" --command=updateConfFile --Server="$HANA_SERVER_ADDRESS:$HANA_SERVER_PORT" \
        --LicenseServer="$LANDSCAPE_SERVER_ADDRESS:$LANDSCAPE_SERVER_PORT" \
        --SLDAddress="$LANDSCAPE_SERVER_PROTOCOL://$LANDSCAPE_SERVER_ADDRESS:$LANDSCAPE_SERVER_PORT" \
        --ComponentID="${SL_COMPONENT_ID:?}" \
        --ClientID="${CLIENT_ID}" --StorePassword="${ENCRYPT_STORE_PASSWORD}" \
		--VerifyTLSCertificate="${CONNECTION_SSL_CERTIFICATE_VERIFICATION}" \
        --srcConfFile="$SL_CONFIG_FOLDER/$SL_CONFIG_FILE.$$" --dstConfFile="$SL_CONFIG_FOLDER"/"$SL_CONFIG_FILE"
    
    return 0
}

if (parameter::no_change 'SL_LB_MEMBERS' 'SL_LB_PORT' 'SL_LB_MEMBER_ONLY' 'SL_THREAD_PER_SERVER'); then
    echo "No need to reconfigure load members and load balancers."
else
    # Stop service
    SERVICES=($(find "$SYSTEMD_FOLDER" -type f -name "$SL_SERVICE_NAME*" | grep -o "$SL_SERVICE_NAME[0-9]*.service$"))
    if [[ -f $SL_SERVICE ]]; then
        for item in ${SERVICES[*]}; do
            SERVICE="${item%.*}"
            stop_service "$SERVICE"
        done
    else
        echo "Warnging: The b1s service script is missing."
    fi
    
    if (parameter::no_change 'SL_LB_MEMBERS' 'SL_LB_PORT' 'SL_LB_MEMBER_ONLY') && (parameter::any_change 'SL_THREAD_PER_SERVER'); then
        echo "Thread number changed."
        config_lb_common_setting
        start_service "$SL_SERVICE_NAME"
    else
        # Remove service
        for item in ${SERVICES[*]}; do
            echo "Removing service $item..."
            SERVICE="${item%.*}"
            remove_service "$SERVICE"
        done
        
        # Remove b1s and backup conf files
        mv "$SL_INSTALLATION_FOLDER"/"$SL_SERVICE_NAME" "$SL_CONFIG_BACKUP_FOLDER"
        find "$SL_CONFIG_FOLDER" -type f  -name "httpd-b1s-lb-member-[1-9]*" -exec mv {} "$SL_CONFIG_BACKUP_FOLDER" \;
        
        config_lb_common_setting
        config_lb_members
        config_lb
        create_b1s_service "$SL_SERVICE_SCRIPT"
    fi
fi


if (parameter::any_change 'SECURITY_CERTIFICATE_ACTION' 'SECURITY_CERTIFICATE_CHECKSUM' 'SECURITY_CERTIFICATE_FILE' 'SECURITY_CERTIFICATE_PASSWD'); then
    # Stop service
    SERVICES=($(find "$SYSTEMD_FOLDER" -type f -name "$SL_SERVICE_NAME*" | grep -o "$SL_SERVICE_NAME[0-9]*.service$"))
    if [[ -f $SL_SERVICE ]]; then
        for item in ${SERVICES[*]}; do
            SERVICE="${item%.*}"
            stop_service "$SERVICE"
        done
    else
        echo "Warnging: The b1s service script is missing."
    fi
    
    mkdir --parents "$SL_CONFIG_BACKUP_FOLDER"
    
    echo "Backup certificate files..."
    cp -pf "$SL_PEM_CERTIFICATE" "$SL_CONFIG_BACKUP_FOLDER"/
    cp -pf "$SL_PEM_CERTIFICATE_KEY" "$SL_CONFIG_BACKUP_FOLDER"/
    cp -pf "$SL_PEM_CERTIFICATE_CHAIN" "$SL_CONFIG_BACKUP_FOLDER"/
    cp -pf "$SL_CONFIG_FOLDER"/"$SL_LB_FILE" "$SL_CONFIG_BACKUP_FOLDER"/
    
    update_certificate
else
    echo "No need to update certificate."
fi

if (parameter::no_change 'CONNECTION_SSL_CERTIFICATE_VERIFICATION'); then
		echo "No need to change certificate vertification status."
else
    mv "$SL_CONFIG_FOLDER/$SL_CONFIG_FILE" "$SL_CONFIG_FOLDER/$SL_CONFIG_FILE.$$"
    python3 "${INSTALL_TEMP_DIR}/Common/support/bin/ServiceLayer_installhelper.py" --command=updateConfFile \
		--VerifyTLSCertificate="${CONNECTION_SSL_CERTIFICATE_VERIFICATION}" \
        --srcConfFile="$SL_CONFIG_FOLDER/$SL_CONFIG_FILE.$$" --dstConfFile="$SL_CONFIG_FOLDER"/"$SL_CONFIG_FILE"
fi

#reconfig if sld address is changed
if (parameter::any_change 'LANDSCAPE_SERVER_ADDRESS' 'LANDSCAPE_SERVER_PORT' 'LOCAL_ADDRESS' 'SL_LB_PORT'); then
    ReRegisterServicelayer
    
    servertools::service::stop
    servertools::service::start
    servertools::service::wait_for_response 300
fi

systemctl daemon-reload
start_service "$SL_SERVICE_NAME"
