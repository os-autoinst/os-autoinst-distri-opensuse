#!/bin/bash

#HDB_CLIENT_PATH
#USER_INSTALL_DIR
#HANA_SERVER_ADDRESS
#HANA_SERVER_PORT
#HANA_SERVER_USER
#HANA_SERVER_PASSWD

#-------------------------------------------------------------------------------
# Writes provided message to stderr.
# Prepends offset depending on the call frame depth.
#
# Arguments:
#   1)  message
# Returns:
#   0   message was written
#-------------------------------------------------------------------------------
function log::info() {
    local offset=2

    while caller $offset > /dev/null; do
        offset=$((offset + 1))
        echo >&2 -n '  '
    done

    echo >&2 "$@"
}

#-------------------------------------------------------------------------------
# Executes KEYTOOL from Java installation directory.
#
# Globals:
#   USER_INSTALL_DIR    installation directory
# Arguments:
#   *)  keytool arguments
# Returns:
#   0   command was executed successfully
#   1   keytool executable does not exist
#   *   keytool error
#-------------------------------------------------------------------------------
function tools::keytool() {
    local -r executable="${USER_INSTALL_DIR:?}/Common/sapmachine_17/bin/keytool"
    
    if ! [[ -e $executable ]]; then
        log::info "Keytool is not available"
        return 1
    fi
    
    log::info "[keytool]: ${*}"
    "$executable" -J-Duser.language=en "$@"
}

function sql_tool() {
    if ! [[ -e "${INSTALL_SCRIPT_TEMP_DIR:?}/SQLTool.jar" ]]; then
        echo >&2 "SQLTool is not available"
        return 1
    fi
    
    "${JAVA_BIN:?}" \
        -XX:TieredStopAtLevel=1 \
        -jar "${INSTALL_SCRIPT_TEMP_DIR:?}/SQLTool.jar" \
        "$@"
}

function sql_tool::execute() {
    sql_tool \
        -serverType 'HANA' \
        -client "${HDB_CLIENT_PATH:?}" \
        -host "${HANA_SERVER_ADDRESS:?}:${HANA_SERVER_PORT:?}" \
        -tenant-db "${HANA_SERVER_TENANT_DB:-}" \
        -user:env 'HANA_SERVER_USER' \
        -passwd:env 'HANA_SERVER_PASSWD' \
        "$@"
}

function sld_tool() {
    if ! [[ -e "${JAVA_BIN}" ]]; then
        echo >&2 "Java executable is not available"
        return 1
    fi
    if ! [[ -e "${INSTALL_SCRIPT_TEMP_DIR:?}/SLDInstallerTool.jar" ]]; then
        echo >&2 "SLDInstallerTool is not available"
        return 1
    fi
    
    "${JAVA_BIN:?}" \
        "-XX:TieredStopAtLevel=1" \
        "-Dcom.sap.b1.ssl.verification=${CONNECTION_SSL_CERTIFICATE_VERIFICATION:-false}" \
        "-Djavax.net.ssl.trustStore=/var/lib/ca-certificates/java-cacerts" \
        -jar "${INSTALL_SCRIPT_TEMP_DIR:?}/SLDInstallerTool.jar" \
        "$@"
}

function b1s_tool() {
    if ! [[ -e "${USER_INSTALL_DIR:?}/Server/bin/B1S-create.jar" ]]; then
        echo >&2 "B1S-create tool is not available"
        return 1
    fi
    
    export LD_LIBRARY_PATH="/usr/lib:/usr/lib64:${LD_LIBRARY_PATH:-}:${USER_INSTALL_DIR:?}/Common/lib:${HDB_CLIENT_PATH:?}"
    
    "${JAVA_BIN:?}" \
        -jar "${USER_INSTALL_DIR:?}/Server/bin/B1S-create.jar" \
        "$@"
}

function sql_execute_statement() {
    sql_tool::execute -statement "$@"
}

function sql_execute_statement_file() {
    sql_tool::execute -statement-file "$@"
}

function sql_execute_query() {
    sql_tool::execute -query "$@"
}

function sql_schema_exists() {
    sql_execute_query "SELECT COUNT(*) FROM PUBLIC.SCHEMAS WHERE SCHEMA_NAME='${1:?}'" -show-titles false | grep 1
    return $?
}

function sql_create_schema() {
    sql_execute_statement "CREATE SCHEMA ${1}"
}

function sql_drop_schema() {
    sql_execute_statement "DROP SCHEMA ${1} CASCADE"
}

function sld_encrypt() {
    sld_tool -encrypt -plaintext "$1" | sed -e 's/true\&//g'
}

function sld_encrypt_env_var() {
    if [ -z "${!1}" ]; then
      echo "Error: $1 is not set or is empty." >&2
      return 1
    fi
  sld_tool -encrypt -plaintextENV "$1" | sed -e 's/true\&//g'
}

function sld_decrypt() {
    sld_tool -encrypt -ciphertext "$1" | sed -e 's/true\&//g'
}

function sld_encrypt_od() {
    sld_tool -encrypt -unprotectedtext "$1" | sed -e 's/true\&//g'
}

function sld_encrypt_statickey() {
    sld_tool -encrypt -statictext "$1" | sed -e 's/true\&//g'
}
