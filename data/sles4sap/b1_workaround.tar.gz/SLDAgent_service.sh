#!/bin/bash

# global variables -------------------------------------------------------------
SLDAGENT_SYSTEMD_SERVICE=sldagent.service

SLDAGENTSVC_UNIT_FILE="/etc/systemd/system/${SLDAGENT_SYSTEMD_SERVICE}"

SLDAGENT_ROOT="${USER_INSTALL_DIR:?}/SLDAgent"
SLDAGENTSVC_CONTROLSCRIPT="${SLDAGENT_ROOT}/service/control.sh"
SLDAGENTSVC_CONTROLENV="${SLDAGENT_ROOT}/service/control.env"
SLDAGENTSVC_CONTROLPID="${SLDAGENT_ROOT}/service/control.pid"
#-------------------------------------------------------------------------------

# Create unit file for systemd service
function __generate_systemd_unit_file() {
    # Unit section
    echo "[Unit]"
    echo "Description=SLD Agent for SAP BusinessOne"
    echo "After=syslog.target"
    echo "After=sapb1servertools.service"
    echo
    
    # Service section
    echo "[Service]"
    echo "Type=forking"
    echo "GuessMainPID=no"
    echo "PIDFile=${SLDAGENTSVC_CONTROLPID}"
    echo "Restart=no"
    echo "TimeoutSec=5min"
    echo "User=root"
    echo "Group=root"
    echo "ExecStart=/bin/bash '${SLDAGENTSVC_CONTROLSCRIPT}' start"
    echo "ExecStop=/bin/bash '${SLDAGENTSVC_CONTROLSCRIPT}' stop"
    echo "EnvironmentFile=${SLDAGENTSVC_CONTROLENV}"
    echo "SuccessExitStatus=143"
    echo
    
    # Install section
    echo "[Install]"
    echo "WantedBy=multi-user.target"
    echo
}

function __generate_env_file() {
    echo "JAVA_HOME=${USER_INSTALL_DIR}/Common/sapmachine_17"
    echo "/usr/lib:/usr/lib64:LD_LIBRARY_PATH=\"${SLDAGENT_ROOT}/libs:\${LD_LIBRARY_PATH}\""
    echo "SLDAGENT_ROOT=${SLDAGENT_ROOT}"
    echo "SLDAGENT_PID=${SLDAGENTSVC_CONTROLPID}"
    echo "SSL_VERIFICATION=${CONNECTION_SSL_CERTIFICATE_VERIFICATION:-false}"
}

function __use_agent() {
    [ -e "${USER_INSTALL_DIR:?}/Common/sapmachine_17/bin/java" ] || return 0
    [ -e "${SLDAGENT_ROOT}/sldAgent.jar" ] || return 0
    
    # workaround for loading of native library from com.sap.security.nw.lps-1.0.1.jar
    export LD_LIBRARY_PATH="/usr/lib:/usr/lib64:${SLDAGENT_ROOT}/libs:${LD_LIBRARY_PATH:-}"
    
    "${USER_INSTALL_DIR:?}/Common/sapmachine_17/bin/java" \
        -Dagent.home="${SLDAGENT_ROOT}" \
        -Dlogback.configurationFile="${SLDAGENT_ROOT}/libs/logback.xml" \
        -Dcom.sap.b1.ssl.verification=${CONNECTION_SSL_CERTIFICATE_VERIFICATION:-false} \
        -Djavax.net.ssl.trustStore="/var/lib/ca-certificates/java-cacerts" \
        -cp "${SLDAGENT_ROOT}/sldAgent.jar:${SLDAGENT_ROOT}/libs/*" \
        com.sap.businessone.agent.Main "$@"
}

function sldagent::system_service::create() {
    echo >&2 "Register SLD Agent service into systemd..."
    
    rm --force '/etc/init.d/sldagent'
    rm --force '/usr/lib/systemd/system/sldagent.service'
    
    rm --force "${SLDAGENTSVC_UNIT_FILE}"
    rm --force "${SLDAGENTSVC_CONTROLENV}"
    rm --force "${SLDAGENTSVC_CONTROLPID}"
    
    __generate_systemd_unit_file > "${SLDAGENTSVC_UNIT_FILE}"
    
    __generate_env_file > "${SLDAGENTSVC_CONTROLENV}"
    chown "${B1_SERVICE_USER:?}:${B1_SERVICE_GROUP:?}" "${SLDAGENTSVC_CONTROLENV}"
    
    systemctl daemon-reload
    systemctl enable $SLDAGENT_SYSTEMD_SERVICE
    
    echo >&2 "Registration into systemd finished."
}

function sldagent::system_service::remove() {
    echo >&2 "Unregister SLD Agent service from systemd..."
    
    if (systemctl is-active --quiet $SLDAGENT_SYSTEMD_SERVICE); then
        systemctl stop $SLDAGENT_SYSTEMD_SERVICE || true
        systemctl disable $SLDAGENT_SYSTEMD_SERVICE || true
    fi
    
    rm --force '/etc/init.d/sldagent'
    rm --force '/usr/lib/systemd/system/sldagent.service'
    
    rm --force "${SLDAGENTSVC_UNIT_FILE}"
    rm --force "${SLDAGENTSVC_CONTROLENV}"
    rm --force "${SLDAGENTSVC_CONTROLPID}"
    
    systemctl daemon-reload
    
    echo >&2 "Unregistration from systemd finished."
}


function sldagent::system_service::activate() {
    __use_agent 'postInstall' \
        -addr "${LANDSCAPE_SERVER_PROTOCOL}://${LANDSCAPE_SERVER_ADDRESS}:${LANDSCAPE_SERVER_PORT}" \
        -adminUser "$SITE_USER" \
        -adminPass "$SITE_PASSWD" \
        -hostname "$LOCAL_ADDRESS"
}

function sldagent::system_service::deactivate() {
    __use_agent 'uninstall'
}

function sldagent::system_service::start() {
    cd / || exit 1
    systemctl start ${SLDAGENT_SYSTEMD_SERVICE}
}

function sldagent::system_service::stop() {
    systemctl stop ${SLDAGENT_SYSTEMD_SERVICE} || true
}
