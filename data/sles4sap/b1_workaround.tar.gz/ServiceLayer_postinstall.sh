#!/bin/bash
set -x

source "${INSTALL_SCRIPT_TEMP_DIR}/WizardUtils_tools.sh"
source "${INSTALL_SCRIPT_TEMP_DIR}/ServerTools_service.sh"
source "${INSTALL_SCRIPT_TEMP_DIR}/ServiceLayer_common.sh"

#input env
#USER_INSTALL_DIR
#SECURITY_CERTIFICATE_FILE
#SECURITY_CERTIFICATE_PASSWD
#SECURITY_CERTIFICATE_ACTION
#SL_THREAD_PER_SERVER
#SL_LB_PORT
#SL_LB_MEMBER_ONLY
#SL_LB_MEMBERS
#HANA_SERVER_ADDRESS
#HANA_SERVER_PORT
#HANA_SERVER_USER
#LANDSCAPE_SERVER_ADDRESS
#LANDSCAPE_SERVER_PORT

# *********************************************************
# Input environment variables
# *********************************************************
# : "${USER_INSTALL_DIR:="/usr/sap/SAPBusinessOne"}"

# : "${SL_THREAD_PER_SERVER:="30"}"
# : "${SL_LB_PORT:="50000"}"
# : "${SL_LB_MEMBERS:="127.0.0.1:50001,127.0.0.1:50002,127.0.0.1:50003"}"
SL_LB_MEMBERS="${SL_LB_MEMBERS// /}"

# : "${HANA_SERVER_TENANT_DB:="DBA"}"
# : "${HANA_SERVER_ADDRESS:="127.0.0.1"}"
# : "${HANA_SERVER_PORT:="30015"}"
# : "${HANA_SERVER_USER:="SYSTEM"}"
# : "${HANA_SERVER_PASSWD:="manager"}"
# : "${SL_LB_MEMBER_ONLY:="false"}"

# : "${SECURITY_CERTIFICATE_PASSWD:="123456"}"
# : "${SECURITY_CERTIFICATE_ACTION:="self"}"

: "${isSLUpgrade:="false"}"

# *********************************************************
# Service Layer folder and files
# *********************************************************
SLD_LOG_FOLDER="$USER_INSTALL_DIR"/logs
SLD_COMMON_LIB_FOLDER="$USER_INSTALL_DIR"/Common/lib
SL_SERVICE_NAME="b1s"
SL_LB_MEMBER_COMMON_FILE="httpd-b1s-lb-member-common.conf"
SL_LB_FILE="httpd-b1s-lb.conf"
SL_CONFIG_FILE="b1s.conf"
SL_SET_HANA_CREDENTIAL_FILE="set-hana-credential"
SL_INSTALLATION_FOLDER="$USER_INSTALL_DIR"/ServiceLayer
SL_BIN_FOLDER="$SL_INSTALLATION_FOLDER"/bin
SL_CONFIG_FOLDER="$SL_INSTALLATION_FOLDER"/conf
SL_LIB_FOLDER="$SL_INSTALLATION_FOLDER"/lib
SL_LOG_FOLDER="$SL_INSTALLATION_FOLDER"/logs
SL_SCRIPTS_FOLDER="$SL_INSTALLATION_FOLDER"/scripts
SL_TEMPLATE_FOLDER="$SL_INSTALLATION_FOLDER"/template
SL_COREDUMP_FOLDER="$SL_INSTALLATION_FOLDER"/coredump
SL_LB_MEMBER_TEMPLATE_FILE="$SL_TEMPLATE_FOLDER"/httpd-b1s-lb-member.conf
SL_CONFIG_SERVICE_FILE="$SL_TEMPLATE_FOLDER"/$SL_SERVICE_NAME
SL_DBCRED_FILE="$SL_LIB_FOLDER"/dbcred.txt
SL_ENCRYPT="$SL_BIN_FOLDER"/B1Encryption
SL_P12_CERTIFICATE="$SL_CONFIG_FOLDER"/certificate.p12
SL_NEW_P12_CERTIFICATE="$SL_CONFIG_FOLDER"/new_certificate.p12
SL_PEM_CERTIFICATE="$SL_CONFIG_FOLDER"/server.crt
SL_PEM_CERTIFICATE_CHAIN="$SL_CONFIG_FOLDER"/server-ca.crt
SL_PEM_CERTIFICATE_KEY="$SL_CONFIG_FOLDER"/server.key
SL_APACHE_CONFIG="service-layer-config"
SL_HOST_NAME=$(hostname)
SL_SERVICETOKEN_KEY="$SL_CONFIG_FOLDER"/STKey.key
# *********************************************************
# Apache HTTP Server folder and files
# *********************************************************
HTTPD_FOLDER="$USER_INSTALL_DIR"/Common/httpd
HTTPD_BIN_FOLDER="$HTTPD_FOLDER"/bin
HTTPD_LIB_FOLDER="$HTTPD_FOLDER"/lib
HTTPD="$HTTPD_BIN_FOLDER"/httpd

# *********************************************************
# Register to sld
# *********************************************************
SL_COMPONENT_ID=
ENCRYPT_STORE_PASSWORD=
CLIENT_ID=
STORE_PASSWORD=

# *********************************************************
# python script folder
# *********************************************************
SCRIPT_FOLDER="$USER_INSTALL_DIR"/Common/support/bin

# *********************************************************
# sl lb member service name list
# *********************************************************
SL_LB_MEMBER_SERVICE_NAME_LIST=

function create_service_layer_conf_file() {
    set +x
    python3 "${INSTALL_TEMP_DIR}/Common/support/bin/ServiceLayer_installhelper.py" --command=updateConfFile --Server="${HANA_SERVER_TENANT_DB}@${HANA_SERVER_ADDRESS}:${HANA_SERVER_PORT}" \
        --LicenseServer="${LANDSCAPE_SERVER_ADDRESS}:${LANDSCAPE_SERVER_PORT}" \
        --SLDAddress="${LANDSCAPE_SERVER_PROTOCOL}://${LANDSCAPE_SERVER_ADDRESS}:${LANDSCAPE_SERVER_PORT}" \
        --ComponentID="${SL_COMPONENT_ID:?}" \
        --HostingEnvironment="${LANDSCAPE_SERVER_TYPE}" \
        --DbUserName="${ENCODED_HANA_SERVER_USER}" --ClientID="${CLIENT_ID}" --StorePassword="${ENCRYPT_STORE_PASSWORD}" \
		--VerifyTLSCertificate="${CONNECTION_SSL_CERTIFICATE_VERIFICATION}" \
        --srcConfFile="${SL_TEMPLATE_FOLDER}/${SL_CONFIG_FILE}.tl" --dstConfFile="${SL_CONFIG_FOLDER}/${SL_CONFIG_FILE}"
    set -x
}

#This function used by upgrade
function restore_service_layer_conf_file() {
    set +x
    python3 "${INSTALL_TEMP_DIR}/Common/support/bin/ServiceLayer_installhelper.py" --command=updateConfFile --Server="${HANA_SERVER_TENANT_DB}@${HANA_SERVER_ADDRESS}:${HANA_SERVER_PORT}" \
        --LicenseServer="${LANDSCAPE_SERVER_ADDRESS}:${LANDSCAPE_SERVER_PORT}" \
        --SLDAddress="${LANDSCAPE_SERVER_PROTOCOL}://${LANDSCAPE_SERVER_ADDRESS}:${LANDSCAPE_SERVER_PORT}" \
        --ComponentID="${SL_COMPONENT_ID:?}" \
        --HostingEnvironment="${LANDSCAPE_SERVER_TYPE}" \
        --DbUserName="${ENCODED_HANA_SERVER_USER}" --ClientID="${CLIENT_ID}" --StorePassword="${ENCRYPT_STORE_PASSWORD}" \
		--VerifyTLSCertificate="${CONNECTION_SSL_CERTIFICATE_VERIFICATION}" \
        --srcConfFile="${TEMP_DIR}/BackUp/ServiceLayer/${SL_CONFIG_FILE}" --dstConfFile="${SL_CONFIG_FOLDER}/${SL_CONFIG_FILE}"
    set -x
}


function merge_service_layer_sqltable_conf() {
    python3 "${SCRIPT_FOLDER}/ServiceLayer_installhelper.py" \
        --command=mergeSqlTableConfig \
        --serviceLayerConfDir="${SL_CONFIG_FOLDER}" \
        --serviceLayerBackupDir="${TEMP_DIR}/BackUp/ServiceLayer"
}


function restore_service_layer_sqltable_conf() {
    SVC_LAYER_BACKUP_DIR="${TEMP_DIR}/BackUp/ServiceLayer"
    
    if [ -f "$SVC_LAYER_BACKUP_DIR/b1s_sqltable.conf" ]; then
        cp "$SVC_LAYER_BACKUP_DIR/b1s_sqltable.conf" "$SERVICE_LAYER_CONF_DIR"
    fi
}



function create_set_hana_credential_file() {
    sed -e "s,USER_INSTALL_DIR,${USER_INSTALL_DIR}," "${SL_TEMPLATE_FOLDER}/${SL_SET_HANA_CREDENTIAL_FILE}.tl" > "${SL_BIN_FOLDER}/${SL_SET_HANA_CREDENTIAL_FILE}"
    
    chown "${B1_SERVICE_USER:?}:${B1_SERVICE_GROUP:?}" "${SL_BIN_FOLDER}/${SL_SET_HANA_CREDENTIAL_FILE}"
    chmod 755 "${SL_BIN_FOLDER}/${SL_SET_HANA_CREDENTIAL_FILE}"
}


function create_httpd_symbol_link() {
    ln -fs "${HTTPD_FOLDER}/cgi-bin/" "${SL_INSTALLATION_FOLDER}/"
    ln -fs "${HTTPD_FOLDER}/modules/" "${SL_INSTALLATION_FOLDER}/"
}

function create_log_symbol_link() {
    mkdir --parents "$SLD_LOG_FOLDER"
    ln -fs "$SL_LOG_FOLDER/" "$SLD_LOG_FOLDER/ServiceLayer"
}

function genpasswd() {
    local l=$1
    [ "$l" == "" ] && l=16
    tr -dc A-Za-z0-9_ < /dev/urandom | head -c ${l} | xargs
}

# Code in the following function is from file "ServerToolsTomcat_postinstall.sh" and modified a little bit
function create_certificate() {
    cp --force "${CERTIFICATE_STORAGE_FILE:?}" "${SL_P12_CERTIFICATE:?}"
    tools::keytool -importkeystore -srckeystore "$SL_P12_CERTIFICATE" -destkeystore "$SL_NEW_P12_CERTIFICATE" -srcstoretype PKCS12 -deststoretype PKCS12 -srcstorepass:env 'SECURITY_CERTIFICATE_PASSWD' -deststorepass:env 'SECURITY_CERTIFICATE_PASSWD'

    # app_options=()
    # if is_v3_upper_openssl; then
    #     app_options+=("-legacy")
    # fi
    # "${app_options[@]}"
    
    # Convert certificate from PKCS12 to PEM format
	echo $SECURITY_CERTIFICATE_PASSWD > passwd.txt
    openssl pkcs12 -in "$SL_NEW_P12_CERTIFICATE" -clcerts -passin file:passwd.txt -nokeys -out "$SL_PEM_CERTIFICATE"
    openssl pkcs12 -in "$SL_NEW_P12_CERTIFICATE" -cacerts -passin file:passwd.txt -nokeys -out "$SL_PEM_CERTIFICATE_CHAIN"
    openssl pkcs12 -in "$SL_NEW_P12_CERTIFICATE" -nocerts -passin file:passwd.txt -nodes -out "$SL_PEM_CERTIFICATE_KEY"
    rm -f "$SL_P12_CERTIFICATE"
    rm -f "$SL_NEW_P12_CERTIFICATE"
	rm passwd.txt
}


#Used by Upgrade
function restore_certificate() {
    if [ -f "$TEMP_DIR/BackUp/ServiceLayer/server.crt" ]; then
        cp "$TEMP_DIR/BackUp/ServiceLayer/server.crt" "$SL_CONFIG_FOLDER"
    fi
    if [ -f "$TEMP_DIR/BackUp/ServiceLayer/server-ca.crt" ]; then
        cp "$TEMP_DIR/BackUp/ServiceLayer/server-ca.crt" "$SL_CONFIG_FOLDER"
    fi
    if [ -f "$TEMP_DIR/BackUp/ServiceLayer/server.key" ]; then
        cp "$TEMP_DIR/BackUp/ServiceLayer/server.key" "$SL_CONFIG_FOLDER"
    fi
}

function create_apache_server_config_tool() {
    sed -e "s,USER_INSTALL_DIR,$1," "${SL_TEMPLATE_FOLDER}/${SL_APACHE_CONFIG}.tl" > "${SL_BIN_FOLDER}/${SL_APACHE_CONFIG}"
    
    chown "${B1_SERVICE_USER}:${B1_SERVICE_GROUP}" "${SL_BIN_FOLDER}/${SL_APACHE_CONFIG}"
    chmod 755 "$SL_BIN_FOLDER/$SL_APACHE_CONFIG"
}

# allow service layer controller to control service layer.
function grant_sudo_command() {
    [[ -z "${B1_SERVICE_USER}" ]] && return 0
    
    rm -f /tmp/sudoers.installer.sl
    oldSudosEntry="$B1_SERVICE_USER ALL=(ALL) NOPASSWD:/usr/bin/systemctl"
    grep -v "$oldSudosEntry" /etc/sudoers > /tmp/sudoers.installer.sl
    
    # cp /etc/sudoers /tmp/sudoers.installer.sl

    grep -qF "$B1_SERVICE_USER ALL=(ALL) NOPASSWD:$SL_BIN_FOLDER/node-service-control.sh" /tmp/sudoers.installer.sl || echo "$B1_SERVICE_USER ALL=(ALL) NOPASSWD:$SL_BIN_FOLDER/node-service-control.sh" >> /tmp/sudoers.installer.sl
    grep -qF "$B1_SERVICE_USER ALL=(ALL) NOPASSWD:$SL_BIN_FOLDER/update-b1s-service.sh" /tmp/sudoers.installer.sl || echo "$B1_SERVICE_USER ALL=(ALL) NOPASSWD:$SL_BIN_FOLDER/update-b1s-service.sh" >> /tmp/sudoers.installer.sl
    (visudo -c -f /tmp/sudoers.installer.sl) || return 1
    EDITOR="cp /tmp/sudoers.installer.sl" visudo
}


LOCAL_HOSTNAME=$(hostname | tr '[:upper:]' '[:lower:]')
ODBC_DRIVER_PATH=$(awk -F= 'system("test -f " $1 "/libodbcHDB.so")==0 {print $1}' "/var/opt/.hdb/${LOCAL_HOSTNAME}/installations.client")
export LD_LIBRARY_PATH="/usr/lib:/usr/lib64:.:${SL_LIB_FOLDER}:${SLD_COMMON_LIB_FOLDER}:${ODBC_DRIVER_PATH}:${LD_LIBRARY_PATH}"

set +x
export HANA_SERVER_USER_ENV=$HANA_SERVER_USER
ENCODED_HANA_SERVER_USER=$("$SL_ENCRYPT" /ENV  HANA_SERVER_USER_ENV)
export HANA_SERVER_PASSWD_ENV=$HANA_SERVER_PASSWD
ENCODED_HANA_SERVER_PASSWD=$("$SL_ENCRYPT" /ENV HANA_SERVER_PASSWD_ENV)
set -x


if [[ $isSLUpgrade == "true" ]]; then
    # Create SSL certificate
    restore_certificate

    # Create Service Layer configuration file to configure HANA
    #restore_service_layer_conf_file
else
    # Create SSL certificate
    create_certificate

    # Create Service Layer configuration file to configure HANA
    #create_service_layer_conf_file
fi

if [[ -f "$SL_PEM_CERTIFICATE" ]]; then
    chmod 400 "$SL_PEM_CERTIFICATE"
fi
if [[ -f "$SL_PEM_CERTIFICATE_CHAIN" ]]; then
    chmod 400 "$SL_PEM_CERTIFICATE_CHAIN"
fi
if [[ -f "$SL_PEM_CERTIFICATE_KEY" ]]; then
    chmod 400 "$SL_PEM_CERTIFICATE_KEY"
fi

# Create symbol link for Apache HTTP server
create_httpd_symbol_link

# Create dbcred.txt
touch "$SL_DBCRED_FILE"

# Create logs folder
mkdir --parents "${SL_LOG_FOLDER}"

create_log_symbol_link

echo "Configuring load balancer..."

# Config some common settings of load balancer members
config_lb_common_setting

chown --recursive "${B1_SERVICE_USER}:${B1_SERVICE_GROUP}" "${HTTPD_FOLDER}"
chown --recursive "${B1_SERVICE_USER}:${B1_SERVICE_GROUP}" "${SL_INSTALLATION_FOLDER}"

# remove all permissions from node-service-control.sh and only grant rx permission for b1service0
chmod ugo-rwx "$SL_BIN_FOLDER/node-service-control.sh"
chown "$(whoami):${B1_SERVICE_GROUP}" "$SL_BIN_FOLDER/node-service-control.sh"
chmod g+x "$SL_BIN_FOLDER/node-service-control.sh"

chmod ugo-rwx "$SL_BIN_FOLDER/update-b1s-service.sh"
chown "$(whoami):${B1_SERVICE_GROUP}" "$SL_BIN_FOLDER/update-b1s-service.sh"
chmod g+x "$SL_BIN_FOLDER/update-b1s-service.sh"

config_lb_members

config_lb

# Create one script to start/stop Service Layer
create_b1s_service


# Create one script to set HANA database user name and password
create_set_hana_credential_file

# Create one script to config apache
create_apache_server_config_tool "$USER_INSTALL_DIR"

#todo: use firewalld to replace SuSEfirewall2
#open_firewall_port

if [[ -d /usr/share/man/man1 ]]; then
    mv "$SL_INSTALLATION_FOLDER"/doc/b1s.1.gz /usr/share/man/man1/
fi

if [[ $isSLUpgrade == "true" ]]; then
    service_layer::landscape::unregister || true
    service_layer::landscape::remove_oauth_client || true
    service_layer::landscape::remove_controller_oauth_client || true
fi

service_layer::webapp::uninstall_context_files
service_layer::webapp::remove_configuration

#Begin to register servicelayer
echo "Register servicelayer to sld..."
servertools::service::check_access_status_of_sld || exit 1

service_layer::landscape::register || exit 1

key=$(openssl rand -base64 32)
echo "${key}" > "$SL_SERVICETOKEN_KEY"
chown "${B1_SERVICE_USER}:${B1_SERVICE_GROUP}" "$SL_SERVICETOKEN_KEY"
chmod 400 "$SL_SERVICETOKEN_KEY"

echo "Register OK"
#End to register servicelayer

#Begin to bind servicelayer
service_layer::landscape::bind || exit 1
#End to bind servicelayer

#Begin service layer controller
echo "Register servicelayer controller..."
service_layer::landscape::register_controller || exit 1
#End service layer controller


#Begin to bind oidc
#get clientID and storePassword from SLDInstallerTool
echo "creating oauth client..."
set +x
result=$(service_layer::landscape::create_oauth_client)
service_layer::landscape::create_controller_oauth_client || exit 1

#On success, the above command returns: true&b1-B1ServiceLayers-1409-main-sbo&Zyl/Sef6J7&yRW1vj55EP&/opt/sap/SAPBusinessOne/ServiceLayer/conf/SLD-config.p12
IFS='&' read -r _ CLIENT_ID _ STORE_PASSWORD _ <<< "${result}"

export STORE_PASSWORD_ENV=$STORE_PASSWORD
ENCRYPT_STORE_PASSWORD=$("$SL_ENCRYPT" /K "${key}" /ENV STORE_PASSWORD_ENV)
#End to bind oidc
set -x

servertools::service::stop

service_layer::webapp::create_configuration
service_layer::webapp::install_context_files

if [[ $isSLUpgrade == "true" ]]; then
    restore_service_layer_conf_file
    merge_service_layer_sqltable_conf
else
    create_service_layer_conf_file
fi

chown "${B1_SERVICE_USER}:${B1_SERVICE_GROUP}" "${SL_CONFIG_FOLDER}/${SL_CONFIG_FILE}"
chmod 755 "${SL_CONFIG_FOLDER}/${SL_CONFIG_FILE}"

servertools::service::start
servertools::service::wait_for_response 300


#decompress the b1s_sdk.zip
rm --recursive --force "${SL_SCRIPTS_FOLDER}/b1s_sdk"
mkdir --parents "${SL_SCRIPTS_FOLDER}/b1s_sdk"

SCRIPT_PACKAGE="$SL_SCRIPTS_FOLDER/b1s_sdk.zip"
if [[ -f "${SCRIPT_PACKAGE}" ]]; then
    # tar -xzvf "${SCRIPT_PACKAGE}" -C "${SL_SCRIPTS_FOLDER}/b1s_sdk"
    unzip -q "${SCRIPT_PACKAGE}" -d "${SL_SCRIPTS_FOLDER}"
    chown --recursive "${B1_SERVICE_USER}:${B1_SERVICE_GROUP}" "${SL_SCRIPTS_FOLDER}/b1s_sdk"
    find "${SL_SCRIPTS_FOLDER}/b1s_sdk" -type f -exec dos2unix -q {} -o {} \;
else
    echo "$SCRIPT_PACKAGE not exist"
fi

#decompress the test.zip
rm --recursive --force "${SL_SCRIPTS_FOLDER}/test"
mkdir --parents "${SL_SCRIPTS_FOLDER}/test"

TEST_PACKAGE="$SL_SCRIPTS_FOLDER/test.zip"
if [[ -f "${TEST_PACKAGE}" ]]; then
    # tar -xzvf "${TEST_PACKAGE}" -C "${SL_SCRIPTS_FOLDER}/test"
    unzip -q "${TEST_PACKAGE}" -d "${SL_SCRIPTS_FOLDER}"
    chown --recursive "${B1_SERVICE_USER}:${B1_SERVICE_GROUP}" "${SL_SCRIPTS_FOLDER}/test"
    find "${SL_SCRIPTS_FOLDER}/test" -type f -exec dos2unix -q {} -o {} \;
else
    echo "${TEST_PACKAGE} not exist"
fi

mv "$SL_TEMPLATE_FOLDER"/b1LogConfig.tl "$SL_LIB_FOLDER"/Conf/b1LogConfig.xml

mkdir --parents "$SL_COREDUMP_FOLDER"
chown --recursive "${B1_SERVICE_USER}:${B1_SERVICE_GROUP}" "$SL_COREDUMP_FOLDER"

grant_sudo_command

if [[ $isSLUpgrade == "true" ]]; then
    SL_EnableAccessLogIfNecessary
fi

#/sbin/service b1s restart
systemctl daemon-reload
if [[ $SL_LB_MEMBER_ONLY == "false" ]]; then
    stop_service "$SL_SERVICE_NAME"
    start_service "$SL_SERVICE_NAME"
else
    IFS=',' read -ra members_arr <<< "$SL_LB_MEMBERS"
    echo "restart installed node the node array is: "
    echo "${members_arr[*]}"
    
    for member in "${members_arr[@]}"; do
        echo "$member"
        IFS=':' read -r _ member_port _ <<< "$member"
        
        echo "Restart node service $member_port"
        stop_service "b1s${member_port}.service"
        start_service "b1s${member_port}.service"
    done
fi
