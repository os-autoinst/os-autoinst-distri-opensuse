#! /bin/bash
set -x

function __find_running_tomcat() {
    pgrep --list-full 'java' \
        | grep "catalina.home=${USER_INSTALL_DIR:?}/Common/tomcat" \
        | awk 'NR==1 { print $1 }'
}

function __kill_running_tomcat() {
    local pid
    
    for ((attempt = 0; attempt < 10; attempt++)); do
        pid=$(__find_running_tomcat)
        [[ -z $pid ]] && return 0
        
        echo >&2 "Terminating process ${pid}"
        kill -9 "${pid}" || true
        sleep 5
    done
    
    return 1
}

#-------------------------------------------------------------------------------
# Tests whether system service for Server Tools is available.
#
# Globals:
#   None
# Arguments:
#   None
# Returns:
#   0   service exists
#   *   service does not exist
#-------------------------------------------------------------------------------
function servertools::service::is_available() {
    {
        systemctl list-unit-files --full --all \
            | grep --fixed-strings --quiet 'sapb1servertools.service'
    } 2> /dev/null
}

#-------------------------------------------------------------------------------
# Starts system service for Server Tools.
#
# Globals:
#   None
# Arguments:
#   None
# Returns:
#   0   service started successfully
#   *   service failed to start
#-------------------------------------------------------------------------------
function servertools::service::start() {
    systemctl start sapb1servertools.service
}

#-------------------------------------------------------------------------------
# Stops system service for Server Tools.
#
# Globals:
#   None
# Arguments:
#   None
# Returns:
#   None
#-------------------------------------------------------------------------------
function servertools::service::stop() {
    systemctl stop sapb1servertools.service || true
    # terminate legacy process if running
    __kill_running_tomcat || true
}

function __read_tomcat_connector() {
    {
        xmlstarlet select --template \
            --value-of "/Server/Service[@name = 'Catalina']/Connector/@${1:?}" \
            "${USER_INSTALL_DIR:?}/Common/tomcat/conf/server.xml"
    } 2> /dev/null
}

function __wait_response() {
    {
        for ((time = 0; time < ${2:?}; time += 5)); do
            curl --silent --insecure --noproxy '*' --output /dev/null "${1:?}" && return 0
            sleep 5
        done
        
        return 1
    } 2> /dev/null
}

#-------------------------------------------------------------------------------
# Waits for response from Apache Tomcat used by Server Tools service.
#
# Globals:
#   USER_INSTALL_DIR
# Arguments:
#   $1  wait time (in seconds)(optional)
# Returns:
#   0   service responses within time limit
#   1   service failed to respond
#-------------------------------------------------------------------------------
function servertools::service::wait_for_response() {
    local -r wait_seconds="${1:-60}"
    local -r path="${2:-}"
    local -r tomcat_port=$(__read_tomcat_connector 'port' || true)
    local tomcat_url=''
    
    case $(__read_tomcat_connector 'SSLEnabled' || true) in
        true)
            tomcat_url="https://localhost:${tomcat_port}${path}"
            ;;
        *)
            tomcat_url="http://localhost:${tomcat_port}${path}"
            ;;
    esac
    
    SECONDS=0
    
    if (__wait_response "${tomcat_url}" "${wait_seconds}"); then
        echo >&2 "Service responsed after ${SECONDS} seconds"
        return 0
    else
        echo >&2 "Service failed to respond in ${wait_seconds} seconds"
        return 1
    fi
}

function servertools::service::check_access_status() {
    local url=$1
    local status

    for i in {0..300..5}; do
        status=$(LD_LIBRARY_PATH=/usr/lib:/usr/lib64 curl -s --insecure -o /dev/null -w "%{http_code}" "$url")
        [[ ${status} -eq 200 ]] && return 0
        sleep 5
    done

    return 1
}

function servertools::service::check_access_status_of_sld() {
    local url="${LANDSCAPE_SERVER_PROTOCOL:?}://${LANDSCAPE_SERVER_ADDRESS:?}:${LANDSCAPE_SERVER_PORT:?}/sld/sld0100.svc/SystemInformation"
    local status

    for i in {0..300..5}; do
        status=$(LD_LIBRARY_PATH=/usr/lib:/usr/lib64 curl -s --insecure -o /dev/null -w "%{http_code}" "$url")
        [[ ${status} -eq 200 ]] && return 0
        sleep 5
    done

    return 1
}
