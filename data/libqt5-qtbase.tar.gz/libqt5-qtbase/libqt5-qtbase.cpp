#include "libqt5-qtbase.h"

libqt5qtbase::libqt5qtbase(QWidget *parent)
    : QMainWindow(parent)
{
    manager = new QNetworkAccessManager (this);
    QObject::connect(manager, SIGNAL(finished(QNetworkReply*)),
                     this, SLOT(finished(QNetworkReply*)));
    manager->get(QNetworkRequest(QUrl("https://www.suse.com")));
}

void libqt5qtbase::finished(QNetworkReply *reply) {
    if(reply->error()) {
        qDebug()<<"Error!";
        exit(1);
    }
    qDebug()<<reply->readAll();
    QApplication::quit();
}

libqt5qtbase::~libqt5qtbase()
{

}
