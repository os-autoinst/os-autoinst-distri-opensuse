#include "libqt5-qtbase.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    libqt5qtbase w;
    w.show();

    return a.exec();
}
