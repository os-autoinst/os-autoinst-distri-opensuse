#ifndef LIBQT5QTBASE_H
#define LIBQT5QTBASE_H

#include <QMainWindow>
#include <QObject>
#include <QApplication>
#include <QtNetwork/QNetworkAccessManager>
#include <QtNetwork/QNetworkRequest>
#include <QtNetwork/QNetworkReply>
#include <QUrl>

class libqt5qtbase : public QMainWindow
{
    Q_OBJECT

public:
    libqt5qtbase(QWidget *parent = 0);
    ~libqt5qtbase();

private slots:
    void finished(QNetworkReply* reply);

private:
    QNetworkAccessManager *manager;

};

#endif // LIBQT5QTBASE_H
