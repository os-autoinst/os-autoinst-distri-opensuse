from setuptools import setup

setup(
    name='pysample_package',
    version='1.0', 
    description='A example Python package',
    author='Yogesh Pagar',
    author_email='ypagar@suse.com',
    packages=['pysample_package'],
)
