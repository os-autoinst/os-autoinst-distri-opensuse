def greet(name):
    print("Hello {}, Welcome to Python World!!".format(name))

def print_hello():
    print("Hello !!!")

#if __name__=="__main__":
#    greet('Yogesh')
