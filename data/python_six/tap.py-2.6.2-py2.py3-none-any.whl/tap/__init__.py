# Copyright (c) 2019, Matt Layman and contributors

from .runner import TAPTestRunner

__all__ = ["TAPTestRunner"]
__version__ = "2.6.2"
