# Copyright (c) 2019, Matt Layman and contributors
"""Tests for tappy"""

from tap.tests.testcase import TestCase  # NOQA
