public class swing {
	public static void main(String[] args) {
		javax.swing.JOptionPane.showMessageDialog(null, "Hello World: Swing");
	}
}
