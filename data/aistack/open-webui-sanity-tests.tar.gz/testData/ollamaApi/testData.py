import os

from dotenv import load_dotenv

load_dotenv()


def create_generate_chat_payload(content):
    payload = {
          "model": "gemma:2b",
          "messages": [
            {
              "role": "user",
              "content": content
            }
          ],
          "stream": "false"
    }
    return payload

