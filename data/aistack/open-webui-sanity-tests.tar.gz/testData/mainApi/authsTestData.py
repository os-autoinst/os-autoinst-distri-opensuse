def create_new_user_payload():
    payload = {
      "name": "Ken Adams",
      "email": "ken.adams@test.com",
      "password": "test123",
      "profile_image_url": "/user.png"
    }
    return payload

