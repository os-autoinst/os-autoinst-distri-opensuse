import os

import pytest
import requests

from actions.auth import do_login

def create_chat(auth_token, payload, base_url):

    response = requests.post(f'{base_url}/api/v1/chats/new', json=payload,
                             headers={
                                 "Content-Type": "application/json",
                                 "authorization": f'Bearer {auth_token}'
                             },
                             verify=False)

    return response



def update_chat(auth_token, chat_id, payload, base_url):
    response = requests.post(f'{base_url}/api/v1/chats/{chat_id}', json=payload,
                             headers={
                                 "Content-Type": "application/json",
                                 "authorization": f'Bearer {auth_token}'
                             },
                             verify=False)
    return response


def create_chat_completion(auth_token, payload, base_url):
    response = requests.post(f'{base_url}/api/task/title/completions', json=payload,
                             headers={
                                 "Content-Type": "application/json",
                                 "authorization": f'Bearer {auth_token}'
                             },
                             verify=False)
    return response


def get_chat_by_id(auth_token, chat_id, base_url):
    response = requests.get(f'{base_url}/api/v1/chats/{chat_id}',
                             headers={
                                 "Content-Type": "application/json",
                                 "authorization": f'Bearer {auth_token}'
                             },
                            verify=False)
    return response


def delete_all_chats(auth_token, base_url):
    response = requests.delete(f'{base_url}/api/v1/chats/',
                             headers={
                                 "Content-Type": "application/json",
                                 "authorization": f'Bearer {auth_token}'
                             },
                             verify=False)
    return response


def delete_chat_by_id(auth_token, chat_id, base_url):
    response = requests.delete(f'{base_url}/api/v1/chats/{chat_id}',
                               headers={
                                   "Content-Type": "application/json",
                                   "authorization": f'Bearer {auth_token}'
                               },
                               verify=False)
    return response