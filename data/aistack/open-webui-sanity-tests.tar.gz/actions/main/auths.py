import pytest
import requests


def create_new_user(auth_token, payload, base_url):
    response = requests.post(f'{base_url}/api/v1/auths/signup', json=payload,
                             headers={
                                 "Content-Type": "application/json",
                                 "authorization": f'Bearer {auth_token}'
                             },
                             verify=False)

    return response