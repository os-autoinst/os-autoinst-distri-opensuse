import requests


def do_login(email, password, base_url):
    payload = {
        'email': email,
        'password': password
    }
    response = requests.post(f'{base_url}/api/v1/auths/signin', json=payload, headers={"Content-Type": "application/json"}, verify=False)

    return response

