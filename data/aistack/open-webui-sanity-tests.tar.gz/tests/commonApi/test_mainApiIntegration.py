import pytest
import os

from actions.main.auths import create_new_user
from actions.main.mainApi import create_chat, delete_all_chats, get_chat_by_id, delete_chat_by_id
from testData.mainApi.testData import create_chat_with_model_payload
from actions.auth import do_login

from dotenv import load_dotenv

load_dotenv()


@pytest.fixture()
def setup_data(get_config):
    base_url = "https://" + os.getenv("OPENWEBUI_HOSTNAME")

    response = do_login(os.getenv("OPENWEBUI_ADMIN_EMAIL"), os.getenv("OPENWEBUI_ADMIN_PWD"), base_url)

    assert response.status_code == 200, '[ERROR] Status code is not equal to 200'
    assert response.json()['token'] != "", '[ERROR] Bearer token came empty'
    yield response.json()['token'], base_url


def test_create_empty_chat(setup_data):
    auth_token, base_url = setup_data
    response = create_chat(auth_token, create_chat_with_model_payload(), base_url)

    assert response.status_code == 200, "[ERROR] Unable to create chat"
    assert response.json()['id'] != "", "[ERROR] Chat not stored"


def test_delete_all_chats(setup_data):
    auth_token, base_url = setup_data
    response = delete_all_chats(auth_token, base_url)

    assert response.content, "[ERROR] The chats were not removed"


def test_create_delete_chat_by_id(setup_data):
    auth_token, base_url = setup_data
    create_new_chat_response = create_chat(auth_token, create_chat_with_model_payload(), base_url).json()

    get_chat_by_id_response = get_chat_by_id(auth_token, create_new_chat_response["id"], base_url)
    assert get_chat_by_id_response.status_code == 200, "[ERROR] Chat not found"
    assert get_chat_by_id_response.json() == create_new_chat_response, "[ERROR] The content stored into the database is not equal to the chat created"

    delete_chat_by_id_response = delete_chat_by_id(auth_token, create_new_chat_response["id"], base_url)
    assert delete_chat_by_id_response.status_code == 200, "[ERROR] Chat was found"





