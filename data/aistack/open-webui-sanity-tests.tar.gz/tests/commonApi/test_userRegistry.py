import os

import pytest
from dotenv import load_dotenv
from actions.auth import do_login
from actions.main.auths import create_new_user
from actions.main.users import get_user_by_id, change_user_role, delete_user_by_id
from testData.mainApi.authsTestData import create_new_user_payload

load_dotenv()

@pytest.fixture()
def setup_data(get_config):
    base_url = "https://" + os.getenv("OPENWEBUI_HOSTNAME")

    response = do_login(os.getenv("OPENWEBUI_ADMIN_EMAIL"), os.getenv("OPENWEBUI_ADMIN_PWD"), base_url)

    assert response.status_code == 200, '[ERROR] Status code is not equal to 200'
    assert response.json()['token'] != "", '[ERROR] Bearer token came empty'
    yield response.json()['token'], base_url


def test_register_and_delete_user(setup_data):
    auth_token, base_url = setup_data

    create_new_user_response = create_new_user(auth_token, create_new_user_payload(), base_url)
    assert create_new_user_response.status_code == 200, f"[ERROR] {create_new_user_response.json()}"
    assert create_new_user_response.json()["id"] is not "", "[ERROR] ID is empty"
    assert create_new_user_response.json()["token"] is not "", "[ERROR] Token is empty"
    user_id = create_new_user_response.json()["id"]

    change_user_role_as_admin_response = change_user_role(auth_token, user_id, base_url)
    assert change_user_role_as_admin_response.status_code == 200, "[ERROR] Error while changing user role"

    login_user_response = do_login(create_new_user_payload()["email"], create_new_user_payload()["password"], base_url)
    assert login_user_response.status_code == 200, '[ERROR] Status code is not equal to 200'
    assert login_user_response.json()['token'] != "", '[ERROR] Bearer token came empty'

    get_user_by_id_response = get_user_by_id(auth_token, user_id, base_url)
    assert get_user_by_id_response.status_code == 200, "[ERROR] User not found"
    assert get_user_by_id_response.json()["name"] == create_new_user_payload()["name"], "[ERROR] Name registered is not equal to the one registered previously"

    delete_user_by_id_as_admin_response = delete_user_by_id(auth_token, user_id, base_url)
    assert delete_user_by_id_as_admin_response.status_code == 200, f"[ERROR] {delete_user_by_id_as_admin_response.json()}"
    assert delete_user_by_id_as_admin_response.json(), "[ERROR] The user was not removed"

    check_if_user_exists_response = get_user_by_id(auth_token, user_id, base_url)
    assert check_if_user_exists_response.status_code == 400, "[ERROR] User still exists"