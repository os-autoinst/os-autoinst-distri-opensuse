import os

import pytest
from dotenv import load_dotenv

load_dotenv()

def pytest_addoption(parser):

    parser.addoption("--URL", action="store", default="local", help="Input Base URL")

@pytest.fixture(autouse=True)
def get_config(request):

    env = request.config.getoption('--URL')

    yield env

