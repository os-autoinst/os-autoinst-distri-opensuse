# open-webui-rbac-testing

RBAC-related tests for `open-webui`.
 
